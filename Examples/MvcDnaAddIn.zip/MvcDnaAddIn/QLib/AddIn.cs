﻿using Function.Interfaces;

namespace Qlib
{
    public class AddIn : IFunctionAddIn
    {
        public void Close()
        {
        }

        public void Open()
        {
        }
    }
}
